//import express and express router as shown in lecture code and worked in previous labs.  Import your data functions from /data/characters.js that you will call in your routes below
import { Router } from 'express';
const router = Router();
import * as sitblog from '../data/sitblog.js';
import validation from '../validation.js';

router.route('/').get(async (req, res) => {
  //code here for GET will render the home handlebars file
  try {
    if(req.session.user){
      const blogList = await sitblog.getAllBlogs();
      res.render('sitblog', { title:'SIT Blog', 
                            loggedIn:true,
                            sitblog:blogList});
    }
     else
       res.render('sitblog', { title:'SIT Blog', loggedIn:false });
  } catch (e) {
    res.status(500).json({error: e});
  }
});

router.route('/').post(async (req, res) => {
    try {
      if(req.session.user){
        //let postTitle = validation.checkString(req.body['postTitleInput'], 'Post title');
        //let postContent = validation.checkString(req.body['postContentInput'], 'Post content');
        //let user = req.session.user;
        // TODO: replace first + last with username
        // I did this because I am wokring in the "postsbranch"
        // And I dont want to adjust user function just yet
        let returnBlog = await createBlog(req.body['blogTitle'], req.body['blogBody'], req.session.user);
        
        console.log("made it to post")

        if (!returnPost) {
          throw "Failed to insert post!";
        }
        res.status(200).redirect('/posts');
      }
    } catch (e) {
      res.status(500).json({ error: e });
    }
});

router
  .route('/register')
  .get(async (req, res) => {
    res.status(200).render('register', {
      title: "Register Page"
    });
  })
  .post(async (req, res) => {
    try {
      let name = req.body['nameInput'];//validation.checkName( 'first name');
      let username = req.body['usernameInput'];//validation.checkName(req.body['lastNameInput'], 'last name');
      let password = req.body['passwordInput'];//validation.checkPassword(req.body['passwordInput'], 'password');
      let confirmPass = req.body['confirmPasswordInput'];//validation.checkPassword(req.body['confirmPasswordInput'], 'confirmation password');
      if (password !== confirmPass)
        throw "Passwords do not match";
      let dbResponse = await sitblog.registerUser(name, username, password);
      if (dbResponse['insertedUser'] === true)
        res.status(200).redirect('login');
      else
        res.status(500).json();
    }
    catch (exception) {
      if (exception.message)
        res.status(500).send(exception.message);
      else
        res.status(500).send(exception);
    }
  });

router.route('/:id').get(async (req, res) => { // update checkbox
  try {
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

router.route('/:id').post(async (req, res) => { // update checkbox
  try {
    if(req.session.user){
      let url = req.url.split('/');
      let id = url[1];
      let updatedPost = {};
      if(req.body){     
        let isChecked = req.body['checked'];
        let isNotChecked = req.body['notChecked'];
        if(isChecked != undefined){
          // add to users upvotes
          let post = await posts.get(id);
          let upvotee = req.session.user._id;
          let foundUpvoteId = post.postUpvotes.find((x) => x === upvotee);
          post.postUpvotes.push(upvotee);
          updatedPost = await posts.update(post);
          updatedPost.value['isChecked'] = true;
          // add to posts user upvote list
        }
        else if(isNotChecked != undefined){
          let post = await posts.get(id);
          let upvotee = req.session.user._id;
          let foundUpvoteId = post.postUpvotes.find((x) => x === upvotee);
          if(foundUpvoteId){
            post.postUpvotes = post.postUpvotes.filter(function(item) {
              return item !== upvotee
            })
          }
          updatedPost = await posts.update(post);
          updatedPost.value['isChecked'] = false;
        }
        else {
          throw "Failed to toggle upvote post!";
        }
        
        res.status(200).send(updatedPost.value);
      }
    }

  } catch (e) {
    res.status(500).json({ error: e });
  }
});

//export router
export default router;
