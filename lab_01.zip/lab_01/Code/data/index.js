import * as events from './events.js';
import * as users from './users.js';

export const eventData = events;
export const userData = users;