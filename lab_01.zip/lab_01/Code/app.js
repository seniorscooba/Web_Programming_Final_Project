import express from 'express';
const app = express();
import configRoutes from './routes/index.js';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import exphbs from 'express-handlebars';

const staticDir = express.static('public');

const handlebarsInstance = exphbs.create({
  defaultLayout: 'main',
  // Specify helpers which are only registered on this instance.
  helpers: {
    asJSON: (obj, spacing) => {
      if (typeof spacing === 'number')
        return new Handlebars.SafeString(JSON.stringify(obj, null, spacing));

      return new Handlebars.SafeString(JSON.stringify(obj));
    },

    partialsDir: ['views/partials/']
  }
});

app.use('/public', staticDir);
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.engine('handlebars', handlebarsInstance.engine);
app.set('view engine', 'handlebars');

app.use(
  session({
    name: 'AuthState',
    secret: "This is a secret.. shhh don't tell anyone",
    saveUninitialized: false,
    resave: false,
    cookie: {maxAge: 60000}
  })
);

app.get('/', (req, res, next) => {
  return res.redirect('/sitblog');
});

app.use('/logout', (req, res, next) => {
if (req.session.user) { // user is authenticated
  next();
} else {
  return res.redirect('/signin');
}
});

configRoutes(app);

const portNum = 3000;
app.listen(portNum, () => {
  console.log("We've now got a server!");
  console.log(`Your routes will be running on http://localhost:${portNum}`);
});
