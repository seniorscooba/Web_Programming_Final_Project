export const mongoConfig = {
  serverUrl: 'mongodb://127.0.0.1:27017/',
  database: 'Vazquez-Steven-CS554-Lab1'
};
